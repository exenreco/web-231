/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2

    Author: Exenreco Bell
    Date:   08/12/2024

    Filename: project01-02.js
*/

//define variables for service name and service speed
var service1Name = "Basic";
var service2Name = "Express";
var service3Name = "Extreme";
var service4Name = "Ultimate";
var service1Speed = "50 Mbsp";
var service2Speed = "100 Mbsp";
var service3Speed = "500 Mbsp";
var service4Speed = "1 Gig";
